package com.goldclick.adsdkdemo;

public class IConstant {
    public static final String TEST_AD_SDK_APPID = "d9b0dd4bf6d27138d4f08d41bdf7153a";
}
