package com.goldclick.adsdkdemo;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.goldclick.core.core.GCAdBanner;
import com.goldclick.core.core.GCAdPop;
import com.goldclick.core.listener.GCAdListener;

public class MainActivity extends AppCompatActivity {
    GCAdPop gcAdPop;
    GCAdBanner gcAdBanner;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gcAdBanner = findViewById(R.id.bannerAd);
        gcAdBanner.setAdListener(new GCAdListener() {
            @Override
            public void loadStart() {
                Log.v(getPackageName(), "loadStart");
            }

            @Override
            public void loadSuccess() {
                Log.v(getPackageName(), "loadSuccess");

            }

            @Override
            public void loadErr(String s) {
                Log.v(getPackageName(), "loadErr>>>" + s);
            }

            @Override
            public void clickAd() {
                Log.v(getPackageName(), "clickAd");
            }
        });


        gcAdPop = new GCAdPop(this);
        gcAdPop.setAdListener(new GCAdListener() {
            @Override
            public void loadStart() {
                Log.v(getPackageName(), "loadStart");
            }

            @Override
            public void loadSuccess() {
                Log.v(getPackageName(), "loadSuccess");
                gcAdPop.show();
            }

            @Override
            public void loadErr(String s) {
                Log.v(getPackageName(), "loadErr>>>" + s);
            }

            @Override
            public void clickAd() {
                Log.v(getPackageName(), "clickAd");
            }
        });
        gcAdBanner.loadAd();
        gcAdPop.loadAd();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (gcAdBanner != null) gcAdBanner.destory();
        if (gcAdPop != null) gcAdPop.destory();
    }
}
