package com.goldclick.adsdkdemo;

import android.app.Application;

import com.goldclick.core.core.GoldClickAd;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        GoldClickAd.init(this, IConstant.TEST_AD_SDK_APPID);
    }
}
